Place this assets folder together with index.html in the same directory.
Reuse your existing assets if already downloaded earlier.
